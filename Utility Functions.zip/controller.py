
import sys
import cv2
from controller import Robot, Camera
from config import (
    WEBOTS_ROBOT_NAME,
    CAMERA_NAME,
    CAMERA_WIDTH,
    CAMERA_HEIGHT,
    CAMERA_ENABLE_TIME
)
from utils import setup_logger, webots_image_to_numpy, numpy_to_jpeg_base64, save_image_locally
from claude_api import query_claude
from navigation import Navigator
from robot_actions import RobotActions

logger = setup_logger(__name__)

class WebotsController:
    """
    Main controller for Webots robot
    Handles camera capture, decision-making, and navigation
    """
    
    def __init__(self):
        """Initialize Webots controller"""
        try:
            self.robot = Robot()
            self.timestep = int(self.robot.getBasicTimeStep())
            
            logger.info("✓ Webots Robot initialized")
            logger.info(f"Timestep: {self.timestep}ms")
            
            # Initialize camera
            self.camera = self.robot.getDevice(CAMERA_NAME)
            if self.camera is None:
                logger.error(f"❌ Camera '{CAMERA_NAME}' not found!")
                sys.exit(1)
            
            self.camera.enable(CAMERA_ENABLE_TIME)
            logger.info(f"✓ Camera enabled: {CAMERA_WIDTH}x{CAMERA_HEIGHT}")
            
            # Initialize modules
            self.navigator = Navigator(self.robot)
            self.robot_actions = RobotActions(self.robot)
            
            # State variables
            self.current_command = None
            self.current_target = None
            self.task_status = "idle"
            
            logger.info("✓ WebotsController initialized successfully")
        
        except Exception as e:
            logger.error(f"Error initializing WebotsController: {e}")
            sys.exit(1)

    def capture_image(self):
        """
        Capture image from Webots camera
        
        Returns:
            Base64 encoded image or None
        """
        try:
            logger.info("📸 Capturing image...")
            
            # Get raw image data
            image_data = self.camera.getImage()
            
            if image_data is None:
                logger.error("❌ Failed to capture image")
                return None
            
            # Convert Webots image to NumPy array
            image_array = webots_image_to_numpy(
                image_data,
                CAMERA_WIDTH,
                CAMERA_HEIGHT
            )
            
            if image_array is None:
                logger.error("❌ Failed to convert image")
                return None
            
            # Save locally for debugging
            save_image_locally(image_array, "captured_frame.jpg")
            
            # Convert to Base64
            image_base64 = numpy_to_jpeg_base64(image_array)
            
            if image_base64 is None:
                logger.error("❌ Failed to encode image to Base64")
                return None
            
            logger.info(f"✓ Image captured and encoded (size: {len(image_base64)} bytes)")
            return image_base64
        
        except Exception as e:
            logger.error(f"Error capturing image: {e}")
            return None

    def process_command(self, command):
        """
        Process user command
        
        Args:
            command: User's natural language command
        
        Returns:
            Task result dictionary
        """
        logger.info(f"📢 Processing command: {command}")
        
        try:
            self.current_command = command
            self.task_status = "processing"
            
            # Step 1: Capture image
            logger.info("Step 1/5: Capturing image...")
            image_base64 = self.capture_image()
            
            if image_base64 is None:
                logger.error("Failed to capture image")
                return {
                    "status": "error",
                    "message": "Failed to capture image",
                    "command": command
                }
            
            # Step 2: Query Claude
            logger.info("Step 2/5: Querying Claude Vision API...")
            claude_response = query_claude(image_base64, command)
            
            if claude_response is None:
                logger.error("Failed to get response from Claude")
                return {
                    "status": "error",
                    "message": "Failed to query Claude API",
                    "command": command
                }
            
            logger.info(f"Claude Response: {claude_response}")
            
            # Step 3: Check if object was found
            if not claude_response.get("found", False):
                logger.warning(f"Object not found: {claude_response.get('object', 'unknown')}")
                return {
                    "status": "not_found",
                    "message": f"Requested object '{claude_response.get('object', 'unknown')}' not found",
                    "command": command,
                    "confidence": claude_response.get("confidence", 0)
                }
            
            # Step 4: Navigate to object
            logger.info("Step 3/5: Navigating to object...")
            target_x = claude_response.get("position", {}).get("x", 0)
            target_y = claude_response.get("position", {}).get("y", 0)
            
            logger.info(f"Target coordinates: ({target_x:.2f}, {target_y:.2f})")
            
            success = self.navigator.go_to(target_x, target_y)
            
            if not success:
                logger.error("Navigation failed")
                return {
                    "status": "error",
                    "message": "Navigation to target failed",
                    "command": command,
                    "target": {"x": target_x, "y": target_y}
                }
            
            # Step 5: Pick up object
            logger.info("Step 4/5: Picking up object...")
            object_name = claude_response.get("object", "object")
            self.robot_actions.pick_up_object(object_name)
            
            # Step 6: Return home
            logger.info("Step 5/5: Returning to home...")
            home_success = self.navigator.return_home()
            
            if not home_success:
                logger.error("Return navigation failed")
                self.robot_actions.drop_object()
                return {
                    "status": "error",
                    "message": "Failed to return home",
                    "command": command
                }
            
            # Drop object
            self.robot_actions.drop_object()
            
            self.task_status = "complete"
            
            logger.info("✅ Task completed successfully!")
            
            return {
                "status": "success",
                "message": f"Successfully completed: {command}",
                "command": command,
                "object": object_name,
                "confidence": claude_response.get("confidence", 0),
                "target": {"x": target_x, "y": target_y}
            }
        
        except Exception as e:
            logger.error(f"Error processing command: {e}")
            self.task_status = "error"
            return {
                "status": "error",
                "message": f"Internal error: {str(e)}",
                "command": command
            }

    def run_step(self):
        """Execute one step of simulation"""
        try:
            if self.robot.step(self.timestep) == -1:
                logger.info("Simulation stopped")
                return False
            return True
        except Exception as e:
            logger.error(f"Error in run_step: {e}")
            return False

    def get_status(self):
        """Get current robot status"""
        return {
            "task_status": self.task_status,
            "current_command": self.current_command,
            "robot_actions": self.robot_actions.get_status(),
            "position": {
                "x": self.navigator.current_x,
                "y": self.navigator.current_y,
                "angle": self.navigator.current_angle
            }
        }
