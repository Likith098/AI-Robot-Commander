
import requests
import json
from config import (
    CLAUDE_API_KEY,
    CLAUDE_MODEL,
    CLAUDE_MAX_TOKENS,
    API_TIMEOUT
)
from utils import setup_logger, parse_claude_response

logger = setup_logger(__name__)

class ClaudeVisionAPI:
    """
    Wrapper for Claude Vision API
    Handles image analysis and structured responses
    """
    
    def __init__(self):
        self.api_key = CLAUDE_API_KEY
        self.model = CLAUDE_MODEL
        self.max_tokens = CLAUDE_MAX_TOKENS
        self.timeout = API_TIMEOUT
        self.endpoint = "https://api.anthropic.com/v1/messages"
        
        if not self.api_key or self.api_key == "your-api-key-here":
            logger.warning("⚠ CLAUDE_API_KEY not properly configured!")
            logger.warning("Set ANTHROPIC_API_KEY environment variable or in config.py")

    def analyze_image(self, image_base64, user_command):
        """
        Send image and command to Claude for analysis
        
        Args:
            image_base64: Base64 encoded image
            user_command: User's natural language command
        
        Returns:
            Parsed JSON response or None
        """
        try:
            logger.info(f"🧠 Querying Claude Vision API...")
            logger.info(f"Command: {user_command}")
            
            # Build request headers
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json"
            }
            
            # Build request payload
            payload = {
                "model": self.model,
                "max_tokens": self.max_tokens,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/jpeg",
                                    "data": image_base64
                                }
                            },
                            {
                                "type": "text",
                                "text": self._build_prompt(user_command)
                            }
                        ]
                    }
                ]
            }
            
            # Send request
            response = requests.post(
                self.endpoint,
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            # Check for errors
            if response.status_code != 200:
                logger.error(f"❌ Claude API Error: {response.status_code}")
                logger.error(f"Response: {response.text}")
                return None
            
            # Parse response
            response_data = response.json()
            message_content = response_data.get("content", [{}])[0].get("text", "")
            
            logger.info(f"✓ Claude responded successfully")
            
            # Parse JSON from response
            parsed = parse_claude_response(message_content)
            return parsed
        
        except requests.exceptions.Timeout:
            logger.error("❌ API request timed out")
            return None
        except requests.exceptions.ConnectionError:
            logger.error("❌ Connection error to Claude API")
            return None
        except Exception as e:
            logger.error(f"❌ Error calling Claude API: {e}")
            return None

    def _build_prompt(self, user_command):
        """Build the prompt for Claude"""
        prompt = f"""You are controlling a mobile service robot in a Webots simulation.

Analyze this camera image and identify the object requested by the user.

User Command: {user_command}

Analyze the image and return ONLY valid JSON (no explanations, no markdown code blocks).

JSON Response Format:
{{
    "object": "name of the detected object",
    "found": true or false,
    "position": {{
        "x": estimated x coordinate (0-10),
        "y": estimated y coordinate (0-10)
    }},
    "distance": estimated distance in meters (0-10),
    "confidence": confidence score (0.0-1.0),
    "description": "brief description of what you see"
}}

IMPORTANT: Return ONLY the JSON, no other text, no markdown."""
        
        return prompt

# ===== SINGLETON INSTANCE =====
claude_api = ClaudeVisionAPI()

def query_claude(image_base64, command):
    """
    Convenience function to query Claude
    
    Args:
        image_base64: Base64 encoded image
        command: User command
    
    Returns:
        Parsed JSON response
    """
    return claude_api.analyze_image(image_base64, command)
