
from utils import setup_logger

logger = setup_logger(__name__)

class RobotActions:
    """
    Handles robot gripper and object manipulation
    """
    
    def __init__(self, robot_controller=None):
        """
        Initialize robot actions
        
        Args:
            robot_controller: Reference to Webots robot controller
        """
        self.robot = robot_controller
        self.gripper_open = True
        self.holding_object = False
        self.held_object_name = None
        
        logger.info("✓ Robot Actions initialized")

    def open_gripper(self):
        """Open the gripper"""
        try:
            logger.info("🔓 Opening gripper...")
            
            if self.robot is None:
                logger.warning("⚠ No robot controller, simulating gripper")
                logger.info("[SIM] Gripper opened")
                self.gripper_open = True
                return
            
            # Try to get gripper device
            gripper = self.robot.getDevice("gripper")
            if gripper is None:
                logger.warning("⚠ Gripper device not found")
                self.gripper_open = True
                return
            
            # Open gripper (set to max position)
            gripper.setPosition(0.05)
            self.gripper_open = True
            logger.info("✓ Gripper opened")
        
        except Exception as e:
            logger.error(f"Error opening gripper: {e}")

    def close_gripper(self):
        """Close the gripper"""
        try:
            logger.info("🔒 Closing gripper...")
            
            if self.robot is None:
                logger.warning("⚠ No robot controller, simulating gripper")
                logger.info("[SIM] Gripper closed")
                self.gripper_open = False
                return
            
            # Try to get gripper device
            gripper = self.robot.getDevice("gripper")
            if gripper is None:
                logger.warning("⚠ Gripper device not found")
                self.gripper_open = False
                return
            
            # Close gripper (set to min position)
            gripper.setPosition(0.0)
            self.gripper_open = False
            logger.info("✓ Gripper closed")
        
        except Exception as e:
            logger.error(f"Error closing gripper: {e}")

    def pick_up_object(self, object_name):
        """
        Simulate picking up an object
        
        Args:
            object_name: Name of the object to pick up
        """
        try:
            logger.info(f"🤲 Picking up {object_name}...")
            
            # Step 1: Open gripper
            self.open_gripper()
            
            # Simulate descent
            if self.robot is None:
                logger.warning("⚠ No robot controller, simulating pickup")
                logger.info("[SIM] Arm descending...")
            
            # Step 2: Close gripper
            self.close_gripper()
            logger.info(f"✓ Gripped {object_name}")
            
            # Step 3: Update state
            self.holding_object = True
            self.held_object_name = object_name
            
            logger.info(f"✓ Successfully picked up {object_name}!")
        
        except Exception as e:
            logger.error(f"Error picking up object: {e}")

    def drop_object(self):
        """Drop the held object"""
        try:
            if not self.holding_object:
                logger.warning("⚠ Robot not holding any object")
                return
            
            object_name = self.held_object_name
            logger.info(f"📦 Dropping {object_name}...")
            
            # Open gripper
            self.open_gripper()
            
            # Update state
            self.holding_object = False
            self.held_object_name = None
            
            logger.info(f"✓ Dropped {object_name}")
        
        except Exception as e:
            logger.error(f"Error dropping object: {e}")

    def get_status(self):
        """Get current robot action status"""
        status = {
            "gripper_open": self.gripper_open,
            "holding_object": self.holding_object,
            "held_object": self.held_object_name
        }
        return status
