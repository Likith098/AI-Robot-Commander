
# 🤖 AI Robot Commander - Webots + Claude Vision + Flask

Complete AI agent for controlling a Webots robot using natural language commands, Claude Vision API for scene understanding, and Flask for web interface.

## 🎯 Project Overview

This project combines:
- **Webots Simulator** - 3D robot simulation
- **Claude Vision API** - AI scene understanding
- **Flask Web Framework** - Web chatbot interface
- **Python 3** - Backend logic
- **ROS 2** (Optional) - Advanced robotics features

### Workflow
```
User Command (Web Interface)
    ↓
Flask Backend
    ↓
Webots Camera Capture
    ↓
Claude Vision API Analysis
    ↓
Robot Navigation & Execution
    ↓
Task Completion
```

---

## 📋 Requirements

- **Python 3.8+**
- **Webots 2023.0+**
- **Windows 10/11** (or Linux/Mac)
- **Claude API Key** from Anthropic
- **Internet Connection** (for Claude API)

---

## 🚀 Installation

### Step 1: Install Webots

1. Download from: https://cyberbotics.com/
2. Install for your OS
3. Create a new robot project

### Step 2: Clone/Extract Project

```bash
# Extract the zip file
unzip ai-robot-commander.zip
cd ai-robot-commander
```

### Step 3: Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

### Step 4: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 5: Configure API Key

1. Get your Claude API key from: https://console.anthropic.com/keys
2. Edit `.env` file:

```env
ANTHROPIC_API_KEY=sk-ant-your-actual-key-here
```

Or set environment variable:

```bash
# Windows PowerShell
$env:ANTHROPIC_API_KEY = "sk-ant-your-key-here"

# Windows CMD
set ANTHROPIC_API_KEY=sk-ant-your-key-here

# Linux/Mac
export ANTHROPIC_API_KEY="sk-ant-your-key-here"
```

---

## 🔧 Webots Setup

### Create Robot in Webots

1. **Open Webots**
2. **Create New Project** → New World
3. **Add Robot:**
   - Add → Mobile Robot → Choose "TurtleBot3" or similar
4. **Add Camera:**
   - Select robot → Add → Device → Camera
   - Name: `camera`
   - Width: 640, Height: 480
5. **Add Ground:**
   - Add → Primitive → Ground Plane
6. **Add Objects:**
   - Add red cylinder, blue sphere, etc.
7. **Save World**

### Export Robot Controller

1. **Create Python Controller:**
   ```
   Right-click Robot → Set controller → New Controller
   ```
2. **Replace generated file with `controller.py`**

---

## ▶️ Running the Project

### Terminal 1: Start Flask Server

```bash
python app.py
```

Expected output:
```
🤖 Starting Flask AI Robot Server
Host: 0.0.0.0
Port: 5000
```

### Terminal 2: Start Webots

1. **Open Webots**
2. **Load your world file**
3. **Assign `controller.py` as robot controller**
4. **Start simulation** (▶️ button)

### Terminal 3: Open Web Interface

```
Open browser to: http://localhost:5000
```

---

## 📖 Usage

### Web Interface

1. **Initialize Robot** - Click "Initialize Robot" button
2. **Enter Command** - Type natural language command:
   - "Bring me the red mug"
   - "Get the blue ball"
   - "Fetch the yellow cup"
3. **View Results** - See robot execute task

### Programmatic Usage

```python
from controller import WebotsController

# Initialize
robot = WebotsController()

# Send command
result = robot.process_command("Bring me the red mug")

# Check result
if result["status"] == "success":
    print(f"✅ Task completed: {result['message']}")
else:
    print(f"❌ Error: {result['message']}")
```

---

## 📁 Project Structure

```
ai-robot-commander/
├── app.py                    # Flask web server
├── controller.py             # Webots robot controller
├── claude_api.py             # Claude Vision API wrapper
├── navigation.py             # Robot navigation logic
├── robot_actions.py          # Gripper & manipulation
├── config.py                 # Configuration
├── utils.py                  # Utility functions
├── requirements.txt          # Python dependencies
├── .env                      # API keys (keep secret!)
├── README.md                 # This file
├── templates/
│   └── index.html            # Web UI
├── captured_frame.jpg        # Last captured image
├── robot_activity.log        # Activity log
└── worlds/
    └── your_world.wbt        # Webots world file
```

---

## ⚙️ Configuration

Edit `config.py` to customize:

```python
# Robot speeds
ROBOT_SPEED = 5.0  # m/s
ROBOT_ANGULAR_SPEED = 1.0  # rad/s

# Camera settings
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

# Home position
HOME_X = 0.0
HOME_Y = 0.0
```

---

## 🔍 API Endpoints

### Initialize Robot
```
POST /api/initialize
Response: {"status": "success"}
```

### Send Command
```
POST /api/command
Body: {"command": "Bring me the red mug"}
Response: {"status": "success", "result": {...}}
```

### Get Status
```
GET /api/status
Response: {"status": "success", "robot_status": {...}}
```

### Get History
```
GET /api/history
Response: {"status": "success", "history": [...]}
```

---

## 🐛 Troubleshooting

### Issue: API Key Error

**Solution:**
```bash
# Check if key is set
echo $ANTHROPIC_API_KEY  # Linux/Mac
echo %ANTHROPIC_API_KEY%  # Windows CMD
```

### Issue: Camera Not Found

**Solution:**
1. In Webots, ensure camera device is named `camera`
2. Add this to robot's .proto file:
```
camera {
  name "camera"